<?php 

	$a = 15;
	echo "Aku adalah angka 15 </br>";


	echo "Jika aku dikali 5 maka, aku sekarang bernilai ".($a*=5) . "</br>" ;	
	echo "Jika aku dibagi 3 maka, aku sekarang bernilai  " .($a/=5) . "</br>";

	echo "Jika aku dikurang 30 maka, aku sekarang bernilai  " . $a=(25 - 30) . "</br>";

	echo "Jika aku ditambah 10 maka, aku sekarang bernilai  " . $a=(-5 + 10)  ;
 ?>