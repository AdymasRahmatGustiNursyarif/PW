<!DOCTYPE html>
<html>
<head>
	<title>latihan1c</title>
	<style type="">
		.container {
			border: 2px solid;
			width: 200px;
			height: 250px;

		}

		.mr {
			margin: 10px;

		}
	</style>
</head>
<body>
	<div class="container">
		<div class="mr">
		<?php
			echo "<table border= 2px solid; table cellpadding= 15px; width= 80px; height= 30px;";		
			echo "
			<tr>
			<th>A</th>
			<th>A</th>
			<th>A</th>";
			echo "</tr> . </table>";

			echo "<table border= 2px solid; table cellpadding=15px; width= 80px; height= 30px;";
			echo "
			<tr>
			<th>B</th>
			<th>B</th>";
			echo "</tr> . </table>";

			echo "<table border= 2px solid; table cellpadding=15px;
			width= 40px; height= 30px;";
			echo "
			<tr>
			<th>C</th>";
			echo "</tr> . </table>";


			echo "</table>";
		?>
		</div>	
	</div>
</body>
</html>