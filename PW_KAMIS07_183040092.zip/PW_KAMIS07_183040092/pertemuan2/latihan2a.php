<?php 
	
	echo "Menggunakan for : ";
	for ($i=1 ; $i<=3; $i++) {
		for ($y=1; $y<=3 ;$y++) {
		echo "Ini perulangan ke ($i,$y) </br>";
		}
	}

	echo "Menggunakan While : ";
	$b = 1;
		while ($b <= 3) {
	$a = 1;
		while ($a <= 3) {
			echo "<li> ini pengulangan ke ($b,$a)</li>";
			$a++;
		}
		$b++;
	}

 ?>