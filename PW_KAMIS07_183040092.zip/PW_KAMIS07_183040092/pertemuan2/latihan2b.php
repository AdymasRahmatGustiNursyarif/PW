<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>latihan2b</title>
	<style type="text/css">
		.kotak {
			height : 10px;
			border: 1px solid black;
		}
		.kotak1 {
			height: 30px;
			border: 1px solid black;
		}
	</style>
</head>
<body>
	<table border="1" cellpadding="3" cellspacing="0">
		<tr>
			<th>Kolom 1</th>
			<th>Kolom 2</th>
			<th>Kolom 3</th>
			<th>Kolom 4</th>
			<th>Kolom 5</th>
		</tr>

			<?php
		for ($a=1; $a<=5; $a++) {
			echo "<tr>"; 
				if ($a%2==1) { for ($b=1; $b<=5; $b++){
				echo "<td class = 'kotak1'> Baris $a, kolom $b";
			}
			} else {
				for ($b=1; $b<= 5; $b++){
					echo "<td class ='kotak'></td>";
				}
			}
		}
		echo "</tr>";
		?>

	</table>
</body>
</html>