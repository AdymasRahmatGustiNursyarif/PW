<!DOCTYPE html>
<html> 
<head>
	<meta charset="utf-8">
	<title>latihan 2d</title>
	<style>
		.kotak {
			width: 30px;
			height: 30px;
			text-align: center;
			line-height: 30px;
			border: 1px solid black;
			float: left;
			margin: 2px;
			color: black;
		}
		.kotak1 {
			background-color: #57e65a;
			width: 30px;
			height: 30px;
			text-align: center;
			line-height: 30px;
			border: 1px solid black;
			float: left;
			margin: 2px;
			color: black;
		}
		.clear {
			
		}
		.ganjil {
			background-color: #003;
			color: #fff;
		}
		.genap {
			background-color: #57e65a
		}
	</style>
</head>
<body>

	<?php
	for ($a=1; $a<=5; $a++){
		for ($b=1; $b <=$a; $b++){
			if($a%2==1){
			echo "<div class='kotak'>#$a</div>
			<div class='kotak1 ganjil'>$b</div>";
		} else {
			echo "<div class='kotak'>#$a</div>
			<div class='kotak1 genap'>$b</div>";
		}
	} echo "<br><br>";	


	}

	?>
	
</body>
</html>