<?php
$kotak = '<table border =1>';
for ($a=1; $a <=5; $a++){
	$kotak .= '<tr>';
	for ($b=1; $b<=5; $b++){
		$warna= '';
		if (($a % 2 == 0 && $b % 2 == 0) ||  ($a % 2 ==1 && $b % 2 == 1)) {
			$warna = 'black';
		}
		else $warna = 'white';
			$kotak .= '<td width=30 height =30 bgcolor ='.$warna.'></td>';
	}
	$kotak .='</tr>';
}
	$kotak .= '</table>';
	echo $kotak;

?>